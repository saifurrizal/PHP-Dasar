<?php
$host = "localhost";
$user = "root";
$pass = "";
$name = "db_gambar";

$koneksi = mysqli_connect($host,  $user,  $pass) or die("Koneksi ke database gagal!");
mysqli_select_db($koneksi, $name) or die("Tidak ada database yang dipilih!");
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Belajar Gambar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
    <div class="container">

        <h1>GAMBAR</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Tambah
        </button>
        <table class="table table-striped">
            <tr>
                <th>NAMA</th>
                <th>GAMBAR</th>
                <th>AKSI</th>
            </tr>
            <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT * FROM gambar");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?= $data['nama']; ?></td>
                        <td><img src="folder_gambar/<?= $data['foto']; ?>" width="50"></td>
                        <td>
                            <a href="edit.php?id=<?php echo $data['id_gambar']; ?>" type="button" class="btn btn-warning">Update</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Modal Tambah -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nama" class="form-label">NAMA</label>
                            <input type="text" name="nama" class="form-control" id="nama" placeholder="Masukkan Nama Anda" required>
                        </div>
                        <div class="mb-3">
                            <label for="foto" class="form-label">FOTO</label>
                            <input type="file" name="foto" class="form-control" id="foto">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Modal Tambah -->

    <?php
    if (isset($_POST['simpan'])) {
        $nama           = $_POST['nama'];

        $nama_file      = $_FILES['foto']['name'];
        $lokasi_file    = $_FILES['foto']['tmp_name'];
        $tipe_file      = $_FILES['foto']['type'];

        move_uploaded_file($lokasi_file, "folder_gambar/$nama_file");

        mysqli_query($koneksi, "INSERT INTO gambar VALUES(NULL,'$nama','$nama_file')");
        header("location: index.php");
    }


    ?>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>