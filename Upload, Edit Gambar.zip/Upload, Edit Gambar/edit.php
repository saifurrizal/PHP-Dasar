<?php
$host = "localhost";
$user = "root";
$pass = "";
$name = "db_gambar";

$koneksi = mysqli_connect($host,  $user,  $pass) or die("Koneksi ke database gagal!");
mysqli_select_db($koneksi, $name) or die("Tidak ada database yang dipilih!");
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Belajar Gambar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
    <?php
    $id = $_GET['id'];
    $sql = mysqli_query($koneksi, "SELECT * FROM gambar WHERE id_gambar='$id'");
    $data = mysqli_fetch_array($sql);
    ?>
    <div class="container">
        <h1>EDIT GAMBAR</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="mb-3">
                    <label for="nama" class="form-label">NAMA</label>
                    <input type="hidden" name="id_gambar" class="form-control" id="nama" value="<?= $data['id_gambar']; ?>" required>
                    <input type="text" name="nama" class="form-control" id="nama" value="<?= $data['nama']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="foto" class="form-label">FOTO</label>
                    <input type="file" name="foto" class="form-control" id="foto" value="<?= $data['foto']; ?>">
                </div>
            </div>
            <img src="folder_gambar/<?= $data['foto']; ?>" width="100">
            <br>
            <br>
            <a href="index.php" type="button" class="btn btn-danger">Batal</a>
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        </form>
    </div>

    <?php
    if (isset($_POST['simpan'])) {
        $id_gambar      = $_POST['id_gambar'];
        $nama           = $_POST['nama'];

        $nama_file      = $_FILES['foto']['name'];
        $lokasi_file    = $_FILES['foto']['tmp_name'];
        $tipe_file      = $_FILES['foto']['type'];

        if ($lokasi_file == "") {
            $simpan = mysqli_query($koneksi, "UPDATE gambar SET nama='$nama' WHERE id_gambar='$id_gambar'");
        } else {
            $data = mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM gambar WHERE id_gambar='$_POST[id_gambar]'"));
            if ($data['foto'] != "") unlink("folder_gambar/$data[foto]");

            move_uploaded_file($lokasi_file, "folder_gambar/$nama_file");
            $simpan =  mysqli_query($koneksi, "UPDATE gambar SET nama='$nama',foto= '$nama_file' WHERE id_gambar='$_POST[id_gambar]'");
        }

        if ($simpan) {
            echo "<script>alert('Data Berhasil disimpan ')</script>";
            echo '<script type="text/javascript">window.location="index.php"</script>';
        } else {
            echo "<script>alert('Gagal Menyimpan Data ')</script>";
            echo '<script type="text/javascript">window.location="edit.php"</script>';
        }
    }


    ?>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>